# from fastapi import APIRouter, Depends, HTTPException, Response
# from services.tiles_service import generate_mvt
# from config import ALLOWED_LAYERS
# from db.session import get_session
# from services import earthengine_service
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Response,
    Query,
)

from services.tiles_service import generate_mvt
from services import earthengine_service
from services import classification_service

from api.schemas import (
    ClassificationMapRequest,
    ClassificationMapResponse,
)

from config import ALLOWED_LAYERS
from db.session import get_session

router = APIRouter()

@router.get("/tiles/{layer}/{z}/{x}/{y}.mvt")
async def get_mvt_tile(
    layer: str,
    z: int,
    x: int,
    y: int,
    session=Depends(get_session)
):
    if layer not in ALLOWED_LAYERS:
        raise HTTPException(status_code=403, detail="Layer not allowed")
    if not (0 <= z <= 22):
        raise HTTPException(status_code=400, detail="Zoom out of range")
    try:
        mvt = await generate_mvt(session, layer, z, x, y)
        return Response(
            content=mvt,
            media_type="application/x-protobuf",
            headers={
                "Access-Control-Allow-Origin": "*",
                # "Cache-Control": "public, max-age=86400"
                            # Prevent caching during development
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0"
            }
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate tile: {e}")

@router.post("/earthengine/get-map", response_model=None)
async def get_map(
    # product: str = Form(..., description="Product name, e.g., 'modis'"),
    # province: str = Form(None, description="Province name, e.g., 'Punjab'"),
    # geometry: str = Form(None, description="Geometry for map (optional)"),
    # input_date: str = Form(..., description="Input date, e.g., '2009-12-31'"),
    # palette: str = Form(None, description="Palette for map (optional)"),
    # session_id: str = Form(None, description="session_id"),
    # db: AsyncSession = Depends(get_db)
        product: str = "modis",
    province: str = "Gauteng",
    geometry: str = None,
    input_date: str = "2009-12-31",
    palette: str = None,
    session_id: str = None, 
):
    # product = "modis"
    # province = "Punjab"
    # geometry = None
    # input_date = "2009-12-31"
    # palette = None
    print("HERE")
    return await earthengine_service.get_et_map(product, province, geometry, input_date, palette, session_id)

@router.post("/earthengine/get-metadata", response_model=None)
async def get_map(
    # product: str = Form(..., description="Product name, e.g., 'modis'"),
    # province: str = Form(None, description="Province name, e.g., 'Punjab'"),
    # geometry: str = Form(None, description="Geometry for map (optional)"),
    # input_date: str = Form(..., description="Input date, e.g., '2009-12-31'"),
    # palette: str = Form(None, description="Palette for map (optional)"),
    # session_id: str = Form(None, description="session_id"),
    # db: AsyncSession = Depends(get_db)
        product_id: str = None,

    session_id: str = None, 
):
    print("HERE")
    return await earthengine_service.get_product_metadata(product_id, session_id)
@router.post(
    "/earthengine/classification/map",
    response_model=ClassificationMapResponse,
)
async def get_supervised_classification_map(
    request: ClassificationMapRequest,

    session_id: str = Query(
        ...,
        description=(
            "Authenticated Earth Engine "
            "session ID"
        ),
    ),
):
    return await (
        classification_service
        .get_classification_map(
            session_id=session_id,
            request_date=request.date,
            mine_id=request.mine_id,
        )
    )
@router.get("/api/mining/hotspot-analysis")
async def mining_hotspot_analysis(session_id: str = Query(None, description="Optional existing Earth Engine session ID")):
    """Return mining-change records and precomputed Gi* results."""
    import asyncio
    from services.hotspot_service import get_analysis
    return await asyncio.to_thread(get_analysis, session_id)

@router.get('/api/mining/change-detection')
async def change_detection(start_year: int, end_year: int, session_id: str = Query(...)):
    import asyncio
    from services.change_detection_service import get_change
    return await asyncio.to_thread(get_change, session_id, start_year, end_year)

@router.get('/api/mining/saved-classification')
async def saved_classification(year: int, session_id: str = Query(...)):
    import asyncio
    from services.saved_classification_service import get_saved_classification
    return await asyncio.to_thread(get_saved_classification, year, session_id)
